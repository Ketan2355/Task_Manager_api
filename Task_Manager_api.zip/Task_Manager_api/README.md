# Task_Manager_api
Django REST API for managing tasks with authentication, CRUD operations, and optional AI text summarization. Built for backend development and portfolio projects.
